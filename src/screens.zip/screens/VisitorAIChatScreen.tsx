import { useRouter } from 'expo-router';
import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';

export default function VisitorAIChatScreen() {
  const router = useRouter();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([
    { id: '1', text: 'Hey, how do I connect my cane with my account?', type: 'sent' },
    { id: '2', text: '1. Tap the menu and select "Connect Cane/Walker".\n2. Then scan the QR code on your cane.\n3. Enter the security code you received. That’s it!', type: 'received' },
    { id: '3', text: 'Thank you so much!!', type: 'sent' }
  ]);

  const sendMessage = () => {
    if (input.trim() !== '') {
      setMessages(prev => [...prev, { id: Date.now().toString(), text: input, type: 'sent' }]);
      setInput('');
    }
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
        <Text style={styles.backButtonText}>← Back</Text>
      </TouchableOpacity>

      <Text style={styles.header}>Visitor AI Chat</Text>

      <FlatList
        style={styles.messages}
        data={messages}
        renderItem={({ item }) => (
          <View style={[styles.bubble, item.type === 'sent' ? styles.sent : styles.received]}>
            <Text>{item.text}</Text>
          </View>
        )}
        keyExtractor={item => item.id}
      />

      <TextInput
        style={styles.input}
        placeholder="Message..."
        value={input}
        onChangeText={setInput}
        onSubmitEditing={sendMessage}
        returnKeyType="send"
      />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 10 },
  backButton: {
    position: 'absolute',
    top: 50,
    left: 20,
    zIndex: 1,
  },
  backButtonText: {
    fontSize: 16,
    color: '#007AFF',
    fontWeight: 'bold',
  },
  header: { fontSize: 20, fontWeight: 'bold', textAlign: 'center', marginVertical: 10 },
  messages: { flex: 1, marginTop: 40 },
  bubble: {
    padding: 12,
    marginVertical: 6,
    marginHorizontal: 10,
    borderRadius: 12,
    maxWidth: '80%',
  },
  sent: {
    backgroundColor: '#dcf8c6',
    alignSelf: 'flex-end'
  },
  received: {
    backgroundColor: '#f1f0f0',
    alignSelf: 'flex-start'
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 20,
    paddingHorizontal: 16,
    height: 44,
    margin: 10
  }
});